
// Lorsqu'une region est selectionnee avec le menu dropdown
$('#selecteur-region').change(function () {

    $('.region-selected').removeClass('region-selected');

    var optionSelected = $(this).children(":selected").attr("id");

    $('a[id=' + optionSelected + ']').addClass('region-selected');
});


// Lorsqu'une region est selectionnee sur la carte
$('#svg-carte > a').click(function (e) { 
    e.preventDefault();
    var regionClicked = $(this).attr("id");

    $('select').val($('#selecteur-region > #'+regionClicked).val());

    // display region en highlight
    $('.region-selected').removeClass('region-selected');

    $('a[id=' + regionClicked + ']').addClass('region-selected');
});
