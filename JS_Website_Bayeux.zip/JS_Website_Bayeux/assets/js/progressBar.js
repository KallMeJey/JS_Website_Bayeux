window.onscroll = function(){
    var winscrool = document.body.scrollTop || document.documentElement.scrollTop;
    var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    var scroled = (winscrool / height) * 100;
    document.getElementById('progress-bar').style.width = scroled + "%";
}