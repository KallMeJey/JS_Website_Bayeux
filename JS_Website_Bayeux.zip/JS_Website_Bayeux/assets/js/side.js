(function(){
    let act = document.querySelector('#active-mb')
    let isl = document.querySelector('#i-mb')
    let dl = false;

    act.addEventListener('click', function(e){
        e.stopPropagation()
        e.preventDefault()
        if(!dl){
            document.getElementById('menu').style.display = 'block';
            

        }else{
            document.getElementById('menu').style.display = 'none';
            
        }
        dl = !dl;
        
    })

    $(window).resize(function(){
       console.log(window.innerWidth); 
    if(window.innerWidth <= 1024) {
        document.getElementById('menu').style.display = 'none';
    }else{
            document.getElementById('menu').style.display = 'flex';
    }
     });

})()

